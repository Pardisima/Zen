from tkinter import ttk
from tkinter import *
import sqlite3


class Producto:

    db = "database/productos.db"

    def __init__(self, root):
        self.ventana = root # Creacion de la ventana grafica
        self.ventana.title("App Gestor de Productos")
        self.ventana.resizable(1, 1) # Se modifica el tamaño (0,0 para que no se modifique)
        self.ventana.wm_iconbitmap("recursos/M6_P2_icon.ico") # Ruta donde guardamos el icono

        # Creacion del contenedor Frame principal
        frame_principal = LabelFrame(self.ventana, text="Registrar Nuevo Producto", bg="orange", fg="white")
        frame_principal.grid(row=0, column=0, columnspan=5, pady=20)

        # Label Nombre
        self.etiqueta_nombre = Label(frame_principal, text="Nombre :", bg="cyan")
        self.etiqueta_nombre.grid(row=1, column=0, columnspan=2)

        # Entry Nombre
        self.nombre = Entry(frame_principal, bg="cyan")
        self.nombre.focus()
        self.nombre.grid(row=1, column=1, columnspan=2)

        # Label Precio
        self.etiqueta_precio = Label(frame_principal, text="Precio :", bg="cyan")
        self.etiqueta_precio.grid(row=2, column=0, columnspan=2)

        # Entry Precio
        self.precio = Entry(frame_principal, bg="cyan")
        self.precio.grid(row=2, column=1, columnspan=2)

        # Label Categoria
        self.etiqueta_categoria = Label(frame_principal, text="Categoria :", bg="cyan")
        self.etiqueta_categoria.grid(row=3, column=0, columnspan=2)

        # Entry Categoria
        self.categoria = Entry(frame_principal, bg="cyan")
        self.categoria.grid(row=3, column=1, columnspan=2)

        # Label Stock
        self.etiqueta_stock = Label(frame_principal, text="Stock :", bg="cyan")
        self.etiqueta_stock.grid(row=4, column=0, columnspan=2)

        # Entry Stock
        self.stock = Entry(frame_principal, bg="cyan")
        self.stock.grid(row=4, column=1, columnspan=2)

        # Boton Añadir Producto
        s = ttk.Style()
        s.configure('my.TButton', font=('Calibri', 14, 'bold'))
        self.boton_agregar = ttk.Button(frame_principal, text="Guardar Producto", command = self.add_producto) # Las funciones de command no llevan ()
        # Sticky maneja las dimensiones del boton referenciando los Puntos Cardinales (N, S, W, E)
        self.boton_agregar.grid(row=5, columnspan=5, sticky=W + E)

        # Mensaje Informativo para el usuario
        self.mensaje = Label(text="", fg="red")
        self.mensaje.grid(row=6, column=0, columnspan=2, sticky=W + E) # No consigo que aparezca entre el boton y la tabla

        # Estilo personalizado para la tabla
        style = ttk.Style()
        style.configure("mystyle.Treeview", highlightthickness=0, bd=0, font=('Calibri',11))  # Se modifica la fuente de la tabla
        style.configure("mystyle.Treeview.Heading", font=('Calibri', 13, 'bold'))  # Se modifica la fuente de las cabeceras
        style.layout("mystyle.Treeview", [('mystyle.Treeview.treearea', {'sticky':'nswe'})])  # Eliminamos los bordes

        # Tabla Productos
        self.tabla = ttk.Treeview(frame_principal, height=20, columns=("#1","#2","#3"))
        self.tabla.grid(row=7, column=0, columnspan=4)
        self.tabla.heading('#0', text="Nombre", anchor=CENTER)
        self.tabla.heading('#1', text="Precio", anchor=CENTER)
        self.tabla.heading('#2', text="Categoria", anchor=CENTER)
        self.tabla.heading('#3', text="Stock", anchor=CENTER)

        # Botones de Eliminar, Editar y Stock
        s = ttk.Style()
        s.configure("my.TButton", font=("Calibri", 14, "bold"))
        boton_eliminar = ttk.Button(text="ELIMINAR", style="my.TButton", command=self.del_producto)
        boton_eliminar.grid(row=8, column=0, columnspan=2 ,sticky=W + E)
        boton_editar = ttk.Button(text="EDITAR", style="my.TButton", command=self.edit_producto)
        boton_editar.grid(row=8, column=3, columnspan=2 , sticky=W + E)


        self.get_productos()

    def db_consulta(self, consulta, parametros= ()):
        with sqlite3.connect(self.db) as con:
            cursor = con.cursor() # Generamos un cursos para poder operar en la bbdd
            resultado = cursor.execute(consulta, parametros) # Preparar consulta SQL con parametros (si los hay)
            con.commit() # Guardamos los cambios en la bbdd

        return resultado

    def get_productos(self):
        # Lo primero, al iniciar la app, vamos a limpiar la tabla por si hubiera datos residuales
        registros_tabla = self.tabla.get_children() # Obtenemos todos los datos de la tabla
        for fila in registros_tabla:
            self.tabla.delete(fila)

        # Consulta SQL
        query = "SELECT * FROM producto ORDER BY nombre DESC"
        registros = self.db_consulta(query) # Se hace la llamada al metodo db.consulta()

        # Escribir los datos en pantalla
        for fila in registros:
            print(fila) # Para verificar por consola los datos
            self.tabla.insert('', 0, text=fila[1], values=(fila[2], fila[3], fila[4]))


    def validacion_nombre(self):
        nombre_introducido_por_usuario = self.nombre.get()
        return len(nombre_introducido_por_usuario) != 0

    def validacion_precio(self):
        precio_introducido_por_usuario = self.precio.get()
        return len(precio_introducido_por_usuario) != 0

    def validacion_stock(self):
        stock_introducido_por_usuario = self.precio.get()
        return len(stock_introducido_por_usuario) != 0

    def add_producto(self):
        if self.validacion_nombre() and self.validacion_precio():
            query = "INSERT INTO producto VALUES(NULL, ?, ?)" # Consulta SQL (sin los datos)
            parametros = (self.nombre.get(), self.precio.get(), self.categoria.get(), self.stock.get()) # Parametros de la consulta SQL
            self.db_consulta(query, parametros)
            print("Datos Guardados")
            self.mensaje["text"] = "Producto {} añadido con éxito".format(self.nombre.get()) # Label ubicado entre el boton y la tabla
            self.nombre.delete(0, END)  # Borrar el campo nombre del formulario
            self.precio.delete(0, END)  # Borrar el campo precio del formulario
            self.categoria.delete(0, END)  # Borrar el campo precio del formulario
            self.stock.delete(0, END)  # Borrar el campo precio del formulario

        elif self.validacion_nombre() and self.validacion_precio() == False:
            self.mensaje["text"] = "Precio obligatorio"

        elif self.validacion_nombre() == False and self.validacion_precio():
            self.mensaje["text"] = "Nombre obligatorio"

        else:
            self.mensaje["text"] = "El Nombre y el Precio son obligatorios"


        self.get_productos() # Al finalizar la insercion de datos invocamos este metodo para actualizar el contenido y ver los cambios

    def del_producto(self):
        # Debug: print(self.tabla.item(self.tabla.selection()))
        # print(self.tabla.item(self.tabla.selection())['text'])
        # print(self.tabla.item(self.tabla.selection())['values'])
        # print(self.tabla.item(self.tabla.selection())['values'][0])
        self.mensaje["text"] = "" # Mensaje inicialmente vacio
        try: # Comprobacion de que se seleccione un producto para poder eliminarlo
            self.tabla.item(self.tabla.selection())["text"][0]
        except IndexError as e:
            self.mensaje["text"] = "Por favor, seleccione un producto para eleminar"
            return
        self.mensaje["text"] = ""
        nombre = self.tabla.item(self.tabla.selection())["text"]
        query = "DELETE FROM producto WHERE nombre = ?"
        self.db_consulta(query, (nombre,))
        self.mensaje["text"] = "Producto {} eliminado con éxito".format(nombre)
        self.get_productos() # Actualizar la tabla de productos

    def edit_producto(self):
        print(self.tabla.item(self.tabla.selection()))
        self.mensaje["text"] = ""
        try:
            self.tabla.item(self.tabla.selection())["text"][0]
        except IndexError as e:
            self.mensaje["text"] = "Por favor, seleccione un producto para editar"
            return
        nombre = self.tabla.item(self.tabla.selection())["text"]
        old_precio = self.tabla.item(self.tabla.selection())["values"][0]
        old_categoria = self.tabla.item(self.tabla.selection())["values"][1]
        old_stock = self.tabla.item(self.tabla.selection())["values"][2]
        self.ventana_editar = Toplevel()  # Crear una ventana por delante de la principal
        self.ventana_editar.title = "Editar Producto"  # Titulo de la ventana
        self.ventana_editar.resizable(0, 0)  # Activar la redimension de la ventana.
        self.ventana_editar.wm_iconbitmap("recursos/M6_P2_icon.ico")
        titulo = Label(self.ventana_editar, text="Edición de Productos",bg="blue", font=("Calibri", 50, "bold"))
        titulo.grid(row=0,column=0)
        # Creacion del Frame para Editar un producto
        frame_editar = LabelFrame(self.ventana_editar, text="Editar el siguiente producto: ",bg="cyan")
        frame_editar.grid(row=1, column=0, columnspan=20, pady=20)
        # Label Nombre Antiguo
        self.etiqueta_nombre_antiguo = Label(frame_editar, text="Nombre Antiguo: ",bg="orange")
        self.etiqueta_nombre_antiguo.grid(row=2, column=0)
        # Entry Nombre Antiguo (no modificable)
        self.input_nombre_antiguo = Entry(frame_editar, textvariable=StringVar(self.ventana_editar, value=nombre), state="readonly",bg="cyan")
        self.input_nombre_antiguo.grid(row=2, column=1)
        # Label Nombre Nuevo
        self.etiqueta_nombre_nuevo = Label(frame_editar, text="Nombre Nuevo: ",bg="cyan")
        self.etiqueta_nombre_nuevo.grid(row=3, column=0)
        # Entry Nombre Nuevo (texto modificable)
        self.input_nombre_nuevo = Entry(frame_editar,bg="cyan")
        self.input_nombre_nuevo.grid(row=3, column=1)
        self.input_nombre_nuevo.focus() # Apuntamos con el raton a este Entry al acceder a esta ventana
        # Label Precio Antiguo
        self.etiqueta_precio_antiguo = Label(frame_editar, text= "Precio Antiguo: ",bg="orange")
        self.etiqueta_precio_antiguo.grid(row=4, column=0)
        # Entry Precio Antiguo (no modificable)
        self.input_precio_antiguo = Entry(frame_editar, textvariable=StringVar(self.ventana_editar, value=old_precio), state="readonly")
        self.input_precio_antiguo.grid(row=4, column=1)
        # Label Precio Nuevo
        self.etiqueta_precio_nuevo = Label(frame_editar, text="Precio Nuevo: ",bg="cyan")
        self.etiqueta_precio_nuevo.grid(row=5, column=0)
        # Entry Precio Nuevo (si modificable)
        self.input_precio_nuevo = Entry(frame_editar,bg="cyan")
        self.input_precio_nuevo.grid(row=5, column=1)
        # Label Categoria Antigua
        self.etiqueta_categoria_antigua = Label(frame_editar, text="Categoria Antigua: ", bg="cyan")
        self.etiqueta_categoria_antigua.grid(row=6, column=0)
        # Entry Categoria Antigua (no modificable)
        self.input_categoria_antigua = Entry(frame_editar, textvariable=StringVar(self.ventana_editar, value=old_categoria), state="readonly")
        self.input_categoria_antigua.grid(row=6, column=1)
        # Label Categoria Nueva
        self.etiqueta_categoria_nueva = Label(frame_editar, text="Categoria Nueva: ", bg="cyan")
        self.etiqueta_categoria_nueva.grid(row=7, column=0)
        # Entry Categoria Nueva ( si modificable)
        self.input_categoria_nueva = Entry(frame_editar, bg="cyan")
        self.input_categoria_nueva.grid(row=7, column=1)
        # Label Stock Antiguo
        self.etiqueta_stock_antiguo = Label(frame_editar, text="Stock Antiguo: ", bg="cyan")
        self.etiqueta_stock_antiguo.grid(row=8, column=0)
        # Entry Stock Antiguo (no modificable)
        self.input_stock_antiguo = Entry(frame_editar, textvariable=StringVar(self.ventana_editar, value=old_stock), state="readonly")
        self.input_stock_antiguo.grid(row=8, column=1)
        # Label Stock Nuevo
        self.etiqueta_stock_nuevo = Label(frame_editar, text="Stock Nuevo: ", bg="cyan")
        self.etiqueta_stock_nuevo.grid(row=9, column=0)
        # Entry Stock Nuevo (si modificable)
        self.input_stock_nuevo = Entry(frame_editar, bg="cyan")
        self.input_stock_nuevo.grid(row=9, column=1)

        # Boton Actualizar Producto
        self.boton_actualizar = ttk.Button(frame_editar, text="Actualizar Producto",
                                           command=lambda:
                                           self.actualizar_productos(self.input_nombre_nuevo.get(), self.input_nombre_antiguo.get(),
                                                                     self.input_precio_nuevo.get(), self.input_precio_antiguo.get(),
                                                                     self.input_categoria_nueva.get(), self.input_categoria_antigua.get(),
                                                                     self.input_stock_nuevo.get(), self.input_stock_antiguo.get()))


        self.boton_actualizar.grid(row=10, columnspan=2, sticky=W + E)

    def actualizar_productos(self, nuevo_nombre, nuevo_precio, nueva_categoria, nuevo_stock, antiguo_nombre, antiguo_precio, antigua_categoria, antiguo_stock):
        producto_modificado = False
        query = "UPDATE producto SET nombre = ?, precio = ?, categoria = ?, stock = ? WHERE nombre = ? AND precio = ? AND categoria = ? AND stock = ?"
        if nuevo_nombre != "" and nuevo_precio != "" and nueva_categoria  != "" and nuevo_stock != "":
             # Si el usuario escribe NUEVOS PARAMETROS, se cambian.
            parametros = (nuevo_nombre, nuevo_precio, nueva_categoria, nuevo_stock, antiguo_nombre, antiguo_precio, antigua_categoria, antiguo_stock)
            producto_modificado = True
        elif nuevo_nombre != "" and nuevo_precio == "":
             # Si el usuario deja vacio el NUEVO PRECIO, se mantiene el pecio anterior
            parametros = (nuevo_nombre, nuevo_precio, nueva_categoria, nuevo_stock, antiguo_nombre, antiguo_precio, antigua_categoria, antiguo_stock)
            producto_modificado = True
        elif nuevo_nombre == "" and nuevo_precio != "":
        # Si el usuario deja vacio el NUEVO NOMBRE, se mantiene el nombre anterior
            parametros = (nuevo_nombre, nuevo_precio, nueva_categoria, nuevo_stock, antiguo_nombre, antiguo_precio, antigua_categoria, antiguo_stock)
            producto_modificado = True

        if producto_modificado:
            self.ventana_editar.destroy()
            self.mensaje["text"] = "El Producto {} NO ha sido Actualizado".format(antiguo_nombre)
        else:
            self.db_consulta(query, parametros)
            self.ventana_editar.destroy() # Cerrar Ventana de Edicion de Producto
            self.mensaje["text"] = "El Producto {} ha sido actualizado".format(antiguo_nombre)
            self.get_productos()


if __name__ == "__main__":
    root = Tk() # Instancia de la ventana principal
    app = Producto(root)



    root.mainloop() # Comenzamos el bucle de la aplicacion, es como un while true
